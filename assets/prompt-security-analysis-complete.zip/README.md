# Prompt 安全分析：完整源码包

这是 Token Security Agent 项目中 Prompt 安全分析、安全对话和连续动作闭环的完整自包含导出包。代码来自当前本地工作树 `feature/unified-security-agent-workbench`，不是只包含几个页面片段的示例。

## 包含内容

- `frontend/`：完整 React + Vite 前端、路由、对话工作区、Prompt 模式、计划、证据、报告、下一步动作和流式显示。
- `backend/app/`：完整 FastAPI 后端，包括安全智能体、案件对话、意图路由、工具编排、Prompt 运行时、语义 Guard、Token 观测、Entropy-CPD、融合策略、知识检索、报告和 SQLite 任务存储。
- `tests/`：前端、后端、API、检测、对话、隐私和回归测试。
- `data/`、`knowledge/`、`configs/`：脱敏演示案例、知识快照、评测清单、数据来源和校准配置。
- `docs/prompt-security-analysis-implementation.md`：按功能拆开的完整实现说明和 GitHub 文件对应表。
- `EXPORT-MANIFEST.txt`：本包实际包含的文件清单。

## Prompt 安全分析主流程

```text
用户输入 Prompt
  -> 创建或恢复同一个安全对话任务
  -> 语义 Guard 判断语义等级
  -> Tokenizer/模型生成 Token 观测
  -> Entropy-CPD 定位分布变化候选
  -> 固定融合策略给出放行/复核/拦截等动作
  -> 智能体引用当前证据解释原因和限制
  -> 主动提供追问、修复、复检、报告等下一步
  -> 用户确认后继续在同一任务中执行
```

已有案件中的“为什么”“哪句话有问题”“这个判断可靠吗”等普通问题默认进入案件对话，不要求固定关键词，也不会自动新建检测任务。只有“重新检测”“生成报告”“修复后复检”等明确控制意图才进入动作或工具执行。

## 关键 GitHub 路径

```text
frontend/src/pages/AgentWorkspacePage.tsx
frontend/src/pages/AnalyzePage.tsx
frontend/src/components/AgentConversation.tsx
frontend/src/components/AgentComposer.tsx
frontend/src/components/AgentPlan.tsx
frontend/src/components/AgentNextSteps.tsx
frontend/src/agent/useAgentTask.ts
frontend/src/agent/taskState.ts
frontend/src/agent/streamingText.ts
frontend/src/agent/localConversation.ts
frontend/src/api.ts
backend/app/api/agent.py
backend/app/api/analyze.py
backend/app/security_agent/coordinator.py
backend/app/security_agent/dialogue.py
backend/app/security_agent/intent.py
backend/app/security_agent/planner.py
backend/app/security_agent/recommendations.py
backend/app/security_agent/tools.py
backend/app/security_agent/models.py
backend/app/security_agent/store.py
backend/app/security_agent/prompt_runtime.py
backend/app/semantic/
backend/app/model/
backend/app/detection/
backend/app/agent/fusion.py
backend/app/knowledge/
knowledge/snapshots/official-v2/
data/demo/
```

完整解释见 `docs/prompt-security-analysis-implementation.md`。

## 本地运行

```powershell
cd frontend
npm install
npm run dev -- --host 127.0.0.1 --port 5174
```

后端依赖见根目录 `pyproject.toml`，入口为 `backend/app/main.py`。使用 `.env.example` 配置模型、校准、知识快照和数据库路径。没有模型时，服务会显示 degraded 并使用受证据约束的降级回答；这不是虚假的检测成功。

## 验证

```powershell
cd frontend
npm.cmd run build
npm.cmd test

cd ..
$env:PYTHONPATH='backend'
.venv\Scripts\python.exe -m pytest
```

## 数据和安全边界

包中包含可以直接复刻原型的脱敏案例、知识卡片、评测清单和聚合报告。没有包含真实完整攻击 Prompt、GCG/AutoDAN/AdvPrompter suffix、Token 文本/ID、Guard 原始输出、密钥、模型原始输出或 PCAP 载荷。评测数据文件中的数量和指标是冻结统计，不代表包里存在同数量的原始样本。

## GitHub 说明

远程仓库：`https://github.com/AlinaaKang/token-security-agent-platform`

当前本地分支：`feature/unified-security-agent-workbench`。本地工作树包含尚未提交的前端对话改动和导出文档，因此 GitHub 远端只有已经推送的提交；本包按当前工作树生成，适合直接交给 Coze 或开发者复刻。

## 当前限制

- 默认未接入外部 LLM API；本地引擎负责检测，证据约束对话服务负责降级回答。接入 LLM 时应只替换对话/规划适配器。
- 当前 SSE 是事件化答案分片，不是模型服务端原生 Token 流。
- 模拟端点、身份和网关连接器仅用于演示，不等于真实 EDR、防火墙或身份平台。
