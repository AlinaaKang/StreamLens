"""Protected, redacted benchmark demonstrations."""
