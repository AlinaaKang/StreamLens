"""Local model observation services."""
