# Prompt 安全分析实现细节

本文件对应项目“面向AI安全的Token流量异常检测智能体平台”中的 Prompt 安全分析与安全对话链路。它描述当前工作树实际实现，不把未接入的外部大模型或不存在的原始数据写成已完成能力。

## 1. 用户入口与任务边界

Prompt 分析有两个入口：

- `frontend/src/pages/AnalyzePage.tsx`：单次 Prompt 分析和检测结果入口。
- `frontend/src/pages/AgentWorkspacePage.tsx`：安全对话入口。创建任务后，用户可以继续追问、查看证据、执行建议动作、生成报告和删除会话。
- `frontend/src/App.tsx`：把 `/analyze`、`/super-agent?mode=prompt` 等路径映射到页面。

安全对话任务由 `workspace_mode="prompt"` 标记。任务创建后，原始用户消息先写入任务消息；后续消息使用同一个 `task_id`，不会重新创建任务。PCAP 任务使用独立的 `workspace_mode="pcap"`，不会把 PCAP 追问路由到 Prompt 最近任务。

## 2. 后端请求链路

```text
POST /api/v1/agent/tasks
  -> backend/app/api/agent.py
  -> backend/app/security_agent/coordinator.py
  -> intent.py 解析任务类型
  -> planner.py 生成公开执行计划
  -> store.py 持久化任务和原始用户消息

POST /api/v1/agent/tasks/{task_id}/messages
  -> coordinator.add_message
  -> 已有案件优先走 dialogue.py
  -> 只有明确控制动作才进入 recommendations.py / playbooks.py / tools.py
  -> 返回更新后的任务快照

POST /api/v1/agent/tasks/{task_id}/messages/stream
  -> 同一个 add_message 服务
  -> api/agent.py 以 SSE 发送 message_start、answer 分片、snapshot、message_end
  -> 前端按分片渐进渲染
```

主要接口定义在 `backend/app/api/agent.py`：

- `GET /api/v1/agent/capabilities`
- `GET /api/v1/agent/connectors`
- `GET /api/v1/agent/knowledge`
- `GET /api/v1/agent/playbooks`
- `GET /api/v1/agent/reports`
- `POST /api/v1/agent/tasks`
- `GET /api/v1/agent/tasks`
- `GET /api/v1/agent/tasks/{task_id}`
- `POST /api/v1/agent/tasks/{task_id}/messages`
- `POST /api/v1/agent/tasks/{task_id}/messages/stream`
- `POST /api/v1/agent/tasks/{task_id}/actions`
- `POST /api/v1/agent/tasks/{task_id}/authorizations`
- `POST /api/v1/agent/tasks/{task_id}/cancel`
- `DELETE /api/v1/agent/tasks/{task_id}`
- `GET /api/v1/agent/tasks/{task_id}/events`
- `GET /api/v1/agent/reports/{report_id}`

## 3. 任务模型与持久化

`backend/app/security_agent/models.py` 定义任务快照、消息、公开计划、观察、证据、假设、建议问题、下一步动作、报告和授权等 Pydantic 模型。前端镜像类型位于 `frontend/src/agent/types.ts`。

`backend/app/security_agent/store.py` 使用 SQLite 保存任务快照和单调递增事件序列。替换快照时校验 `version`，发现并发修改返回冲突；事件流可以在刷新后从 `last-event-id` 恢复。用户任务删除接口会删除服务端任务，前端同时清理当前选择和浏览器侧用户消息映射。

服务初始化位于 `backend/app/main.py`：

- 创建 `SecurityAgentStore`。
- 创建 Prompt 运行时 `PromptAgentRuntime`。
- 创建受证据约束的 `GroundedDialogueService`。
- 创建工具注册表 `build_registry`。
- 注册模拟端点、身份、网关连接器，以及 Prompt 分析和复检工具。

## 4. 自然语言对话路由

`backend/app/security_agent/coordinator.py` 是任务编排核心。它遵循以下优先级：

1. 有当前任务和案件证据时，普通句子默认视为案件追问。
2. “为什么”“哪句话有问题”“这个结论可靠吗”“我不明白”等不再要求固定关键词，也不会新建任务。
3. 只有明确的控制目标，例如“重新检测”“生成报告”“修复后复检”“扩大调查范围”“取消任务”，才执行建议动作或工具调用。
4. 对话回答只能引用当前任务的原始用户 Prompt 摘要、检测结果、观察、证据编号、假设、限制和历史消息。

`backend/app/security_agent/intent.py` 负责新任务意图和控制意图解析；它不承担已有案件的普通问答。`backend/app/security_agent/dialogue.py` 负责案件内解释和追问。`backend/app/security_agent/education.py` 负责新任务首次响应中的说明性内容。

无外部 LLM 时，`GroundedDialogueService` 使用当前证据构造可读降级回答；不会用“超出专业范围”替代案件解释，也不会凭空生成 Packet、Token 或检测结果。

## 5. Prompt 检测引擎

Prompt 检测由本地安全引擎完成，模型层只负责对话和决策：

- `backend/app/semantic/models.py`：语义 Guard 结构化输出模型。
- `backend/app/semantic/parser.py`：严格解析 Guard 输出，非法或缺字段时标记不可用。
- `backend/app/semantic/runtime.py`：调用配置的语义模型并施加输入、输出和超时限制。
- `backend/app/model/runtime.py`：加载 Tokenizer/模型，生成用户 Token 的 logits/entropy/NLL。
- `backend/app/model/token_stats.py`：Token 观测的内部模型与脱敏映射。
- `backend/app/detection/baselines.py`：固定 system Prompt 基线和统计量。
- `backend/app/detection/calibration.py`、`calibrator.py`：用 calibration/dev 数据选择阈值和工作点。
- `backend/app/detection/cpd.py`：Entropy-CPD 在线累积变化点检测和异常起点定位。
- `backend/app/agent/fusion.py`：语义等级、Token 分布候选和工作模式的固定融合表。
- `backend/app/agent/policy.py`：放行、拦截、复核、净化后复检等动作约束。

融合结果中的 `token_anomaly_candidate` 只表示 Token 分布异常候选，不等同于“恶意”。直接危险语义由语义 Guard 拦截；语义安全但出现分布候选时，按模式和固定策略进入复核或其他受限动作。

## 6. 证据、知识和报告

`backend/app/security_agent/adapters.py` 将工具结果转换成公开观察和证据引用，并拒绝私有字段。`backend/app/security_agent/reporting.py` 只从任务已存在的证据构建报告，不接受用户任意证据 ID。

知识层位于：

- `backend/app/knowledge/loader.py`
- `backend/app/knowledge/models.py`
- `backend/app/knowledge/query.py`
- `backend/app/knowledge/retriever.py`
- `backend/app/knowledge/service.py`
- `backend/app/knowledge/reporting.py`
- `knowledge/snapshots/official-v2/`

知识检索用于解释、引用和报告，不改写基础检测动作。报告生成有模型路径和确定性模板降级路径；报告内容保留证据 ID、来源和限制，不包含隐藏思维链、完整攻击 Prompt、Token 文本或模型原始输出。

## 7. 建议动作、授权与闭环

`backend/app/security_agent/recommendations.py` 根据当前任务状态生成推荐追问和下一步动作。`backend/app/security_agent/playbooks.py` 读取安全剧本。`backend/app/security_agent/tools.py` 注册工具、权限级别、参数 schema、最大调用次数和是否允许自动执行。

典型闭环：

```text
提交 Prompt
  -> 语义 Guard + Token 观测 + Entropy-CPD + 固定融合
  -> 解释证据和限制
  -> 建议“查看依据 / 生成修复方案 / 修复后复检 / 生成报告”
  -> 用户点击建议
  -> 只读动作直接执行；有影响动作要求授权
  -> 观察执行结果并追加到同一任务
```

`coordinator.py` 的 `run_until_blocked` 和 `execute_action` 负责连续动作。`authorization` 状态和 `AgentAuthorizationRequest` 约束高影响动作必须由用户确认。所有执行都绑定当前任务、工具和授权范围。

## 8. 前端对话与流式显示

- `frontend/src/pages/AgentWorkspacePage.tsx`：安全对话工作区、模式分流、任务恢复、计划、证据、报告和动作。
- `frontend/src/components/AgentConversation.tsx`：消息时间线、用户原始消息、智能体回答、状态消息和错误重试。
- `frontend/src/components/AgentComposer.tsx`：Prompt/PCAP 模式切换、输入、上传和发送。
- `frontend/src/components/AgentPlan.tsx`：公开执行计划，固定显示在对话区前部。
- `frontend/src/components/AgentNextSteps.tsx`：推荐追问与建议动作分组。
- `frontend/src/components/AgentEvidenceInspector.tsx`、`AgentPromptInspector.tsx`：证据和 Prompt 任务摘要。
- `frontend/src/components/AgentReportInspector.tsx`：报告和下载入口。
- `frontend/src/agent/useAgentTask.ts`：任务快照、SSE 事件流、断线轮询、刷新恢复。
- `frontend/src/agent/taskState.ts`：单调事件状态归并，防止旧事件覆盖新状态。
- `frontend/src/agent/streamingText.ts`：将服务端分片平滑排队，按短间隔逐步更新文字。
- `frontend/src/agent/localConversation.ts`：只在浏览器保存当前任务的用户消息，用来恢复原始用户 Prompt 显示；不保存服务端检测结果或 Token 内容。
- `frontend/src/agent/workspaceMode.ts`：Prompt/PCAP 工作区分流和 URL 生成。
- `frontend/src/api.ts`：所有 API 请求、SSE 消费、文件上传和错误处理。

流式接口当前是事件化分片传输：服务端先发送结构化快照，再由前端按分片渲染。它提供 Codex 式渐进显示，但不代表后端模型已经逐 Token 生成；真正模型 Token 流可以在同一事件协议上替换，不需要改变页面状态模型。

## 9. 隐私与安全边界

隐私约束由后端模型校验、适配器、事件存储、API 测试和脚本共同保证。禁止公开或持久化：

- 完整原始 Prompt 和攻击 suffix
- Token 文本、Token ID 和模型原始 logits
- Guard 原始输出和隐藏推理
- 外部查询词、密钥、真实 PCAP 载荷

相关验证：`tests/unit/test_security_agent_*.py`、`tests/integration/test_security_agent_api.py`、`tests/unit/test_verify_lab_privacy.py`、`scripts/verify_lab_privacy.ps1`。

## 10. 数据和评测文件

当前仓库可直接复制的脱敏数据位于 `data/demo/` 和 `knowledge/snapshots/official-v2/`。`data/agent-ablation-v1-*`、`data/knowledge-evaluation-*`、`data/report-generation-*` 保存冻结评测清单、哈希、配置和聚合指标，不包含完整攻击 Prompt。来源、许可证和导入规则见 `configs/datasets.yaml`、`data/README.md`、`THIRD_PARTY_NOTICES.md`。

## 11. 测试覆盖

前端测试覆盖：

- `frontend/src/AgentWorkspacePage.test.tsx`
- `frontend/src/components/AgentConversation.test.tsx`
- `frontend/src/agent/*.test.ts`
- `frontend/src/api.test.ts`

后端测试覆盖：

- `tests/unit/test_security_agent_*.py`
- `tests/integration/test_security_agent_api.py`
- `tests/integration/test_analyze_api.py`
- `tests/integration/test_basic_workflow.py`
- `tests/unit/test_cpd.py`
- `tests/unit/test_fusion_policy.py`
- `tests/unit/test_semantic_parser.py`
- `tests/unit/test_model_runtime.py`

前端构建命令：`npm.cmd run build`。前端测试命令：`npm.cmd test`。后端使用项目 `.venv` 执行 `python -m pytest`。

## 12. GitHub 文件对应关系

远程仓库：`https://github.com/AlinaaKang/token-security-agent-platform`

当前实现所在本地分支：`feature/unified-security-agent-workbench`。工作树存在未提交修改，因此 GitHub 上只有已推送的提交才会包含这些最新改动；导出包按当前工作树内容生成。

最重要的 GitHub 相对路径：

| 功能 | 文件/目录 |
| --- | --- |
| 页面和路由 | `frontend/src/App.tsx`, `frontend/src/pages/AnalyzePage.tsx`, `frontend/src/pages/AgentWorkspacePage.tsx` |
| 对话 UI | `frontend/src/components/AgentConversation.tsx`, `AgentComposer.tsx`, `AgentPlan.tsx`, `AgentNextSteps.tsx` |
| 任务状态与流式 | `frontend/src/agent/useAgentTask.ts`, `taskState.ts`, `streamingText.ts`, `localConversation.ts` |
| API 客户端 | `frontend/src/api.ts` |
| 后端 API | `backend/app/api/agent.py`, `backend/app/api/analyze.py` |
| 案件编排 | `backend/app/security_agent/coordinator.py`, `dialogue.py`, `intent.py`, `planner.py` |
| 任务与消息模型 | `backend/app/security_agent/models.py`, `store.py` |
| 建议动作和工具 | `backend/app/security_agent/recommendations.py`, `playbooks.py`, `tools.py`, `policy.py` |
| Prompt 运行时 | `backend/app/security_agent/prompt_runtime.py`, `backend/app/semantic/`, `backend/app/model/` |
| Token/CPD 检测 | `backend/app/detection/`, `backend/app/agent/fusion.py` |
| 知识和报告 | `backend/app/knowledge/`, `backend/app/security_agent/reporting.py` |
| 数据 | `data/demo/`, `knowledge/snapshots/official-v2/`, `configs/datasets.yaml` |
| 测试 | `tests/unit/test_security_agent_*.py`, `tests/integration/test_security_agent_api.py`, `frontend/src/agent/*.test.ts` |

## 13. 当前限制

- 默认没有外部 LLM API；对话使用证据约束的本地/确定性降级回答。接入 LLM 时只替换对话生成和规划适配器，不能让模型直接执行检测或写入证据。
- 流式目前是答案分片事件，不是模型服务端原生 Token 流。
- 评测中心的冻结样本只保留统计和哈希，不能从仓库恢复完整攻击 Prompt。
- 模拟端点、身份和网关连接器用于演示，不能当作真实 EDR、防火墙或身份平台连接。
- Prompt 检测需要配置模型、校准文件和知识快照；服务未配置时健康状态会显示 degraded，这是可审计降级，不是“检测通过”。
