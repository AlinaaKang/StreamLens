# Conversation-first security workspace

## Goal

Keep ordinary conversation visually natural while preserving the auditable workflow for security investigations.

## Display rules

- A conversation task with no plan and no evidence renders only messages and the composer.
- Suggested questions render only after a case has evidence or the agent has explicit follow-up options.
- The execution plan, progress, authorization, and limitations render for detection tasks or tasks with an execution plan.
- PCAP upload progress remains visible while an upload is active.

## Acceptance

- "你能聊天吗" does not show a plan, progress bar, authorization panel, or conclusion-boundary panel.
- Prompt/PCAP detection tasks continue to show their plan and authorization state.
- Existing evidence cases continue to show grounded follow-up controls and limitations.
