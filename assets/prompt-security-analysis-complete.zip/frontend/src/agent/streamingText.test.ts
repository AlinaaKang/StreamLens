import { afterEach, describe, expect, it, vi } from "vitest";

import { createStreamingTextController } from "./streamingText";

afterEach(() => vi.useRealTimers());

describe("streaming text controller", () => {
  it("reveals queued assistant text one character at a time", async () => {
    vi.useFakeTimers();
    const updates: string[] = [];
    const controller = createStreamingTextController((value) => updates.push(value), 20);

    controller.push("你好");
    expect(updates).toEqual([]);

    await vi.advanceTimersByTimeAsync(20);
    expect(updates).toEqual(["你"]);
    await vi.advanceTimersByTimeAsync(20);
    expect(updates).toEqual(["你", "你好"]);

    controller.dispose();
  });
});
