export interface StreamingTextController {
  push: (content: string) => void;
  waitForIdle: () => Promise<void>;
  reset: () => void;
  dispose: () => void;
}

export function createStreamingTextController(
  onUpdate: (content: string) => void,
  intervalMs = 24,
): StreamingTextController {
  let queue: string[] = [];
  let timer: ReturnType<typeof setInterval> | null = null;
  let visible = "";
  let waiters: Array<() => void> = [];

  function resolveWaiters() {
    const pending = waiters;
    waiters = [];
    pending.forEach((resolve) => resolve());
  }

  function stop() {
    if (timer !== null) {
      clearInterval(timer);
      timer = null;
    }
    if (queue.length === 0) resolveWaiters();
  }

  function tick() {
    const next = queue.shift();
    if (next === undefined) {
      stop();
      return;
    }
    visible += next;
    onUpdate(visible);
  }

  function ensureRunning() {
    if (timer !== null || queue.length === 0) return;
    timer = setInterval(tick, Math.max(1, intervalMs));
  }

  return {
    push(content) {
      if (!content) return;
      queue.push(...Array.from(content));
      ensureRunning();
    },
    waitForIdle() {
      if (queue.length === 0 && timer === null) return Promise.resolve();
      return new Promise<void>((resolve) => waiters.push(resolve));
    },
    reset() {
      queue = [];
      visible = "";
      stop();
      onUpdate(visible);
    },
    dispose() {
      queue = [];
      stop();
      waiters = [];
    },
  };
}
