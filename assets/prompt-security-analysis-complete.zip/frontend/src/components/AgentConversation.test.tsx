import { cleanup, fireEvent, render, screen, within } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import type { AgentEvidence, AgentMessage, AgentPlanStep } from "../agent/types";
import { AgentConversation } from "./AgentConversation";

afterEach(cleanup);

const messages: AgentMessage[] = [
  { message_id: "u1", role: "user", kind: "message", content: "检查这个 Prompt", created_at: new Date(2026, 8, 7, 8, 10).toISOString(), evidence_scope: "none", evidence_refs: [] },
  { message_id: "a1", role: "agent", kind: "result", content: "已完成检查", created_at: new Date(2026, 8, 7, 8, 11).toISOString(), evidence_scope: "current_case", evidence_refs: [] },
];

describe("AgentConversation", () => {
  it("renders semantic timestamps beside both speaker names", () => {
    render(<AgentConversation messages={messages} now={new Date(2026, 8, 7, 12, 0)} />);

    const conversation = screen.getByRole("region", { name: "任务对话" });
    const times = Array.from(conversation.querySelectorAll("time"));
    expect(times.map((time) => time.textContent)).toEqual(["08:10", "08:11"]);
    expect(times[0]).toHaveAttribute("datetime", messages[0].created_at);
    expect(times[0]).toHaveAttribute("title", expect.stringContaining("2026年9月7日"));
  });

  it("explains and clears browser-local original text without deleting the task", () => {
    const clear = vi.fn();
    render(<AgentConversation messages={messages} localContentAvailable onClearLocalConversation={clear} />);

    expect(screen.getByText("原文已保存到当前案件，审计记录仍保持脱敏")).toBeVisible();
    fireEvent.click(screen.getByRole("button", { name: "清除浏览器副本" }));
    expect(clear).toHaveBeenCalledOnce();
  });

  it("places the user body before its right-side avatar and the agent avatar before its output", () => {
    render(<AgentConversation messages={messages} />);

    const rows = screen.getByRole("region", { name: "任务对话" }).querySelectorAll("article");
    expect(rows[0]).toHaveClass("is-user");
    expect(rows[0].firstElementChild).toHaveClass("agent-message-body");
    expect(rows[0].lastElementChild).toHaveClass("agent-message-avatar");
    expect(rows[1].firstElementChild).toHaveClass("agent-message-avatar");
    expect(rows[1].lastElementChild).toHaveClass("agent-message-body");
  });

  it("places the public plan after the initial user message in the conversation timeline", () => {
    const plan: AgentPlanStep[] = [
      { step_id: "step_01", tool_id: "inspect_prompt", status: "running", requires_authorization: false, summary: "检查 Prompt 风险", depends_on: [], attempt: 1 },
    ];

    render(<AgentConversation messages={messages} plan={plan} planRevision={0} />);

    const conversation = screen.getByRole("region", { name: "任务对话" });
    const timeline = Array.from(conversation.children);
    expect(timeline.map((item) => item.getAttribute("aria-label") ?? item.className)).toEqual([
      "agent-message is-user is-message",
      "执行计划",
      "agent-message is-agent is-result",
    ]);
  });

  it("places plan progress immediately after the public plan", () => {
    const plan: AgentPlanStep[] = [
      { step_id: "step_01", tool_id: "inspect_prompt", status: "succeeded", requires_authorization: false, summary: "检查 Prompt 风险", depends_on: [], attempt: 1 },
    ];

    render(<AgentConversation messages={messages} plan={plan} progress={{ finished: 1, total: 1 }} />);

    const timeline = Array.from(screen.getByRole("region", { name: "任务对话" }).children);
    expect(timeline.map((item) => item.getAttribute("aria-label") ?? item.className)).toEqual([
      "agent-message is-user is-message",
      "执行计划",
      "计划进度",
      "agent-message is-agent is-result",
    ]);
  });

  it("uses the streaming answer in place of the persisted final answer", () => {
    render(<AgentConversation messages={messages} streamingContent="正在分析" streamingMessageId="a1" />);

    const conversation = screen.getByRole("region", { name: "任务对话" });
    expect(screen.getByText("正在分析")).toBeVisible();
    expect(screen.queryByText("已完成检查")).not.toBeInTheDocument();
    expect(conversation.querySelectorAll("article")).toHaveLength(2);
  });

  it("shows a grounded result breakdown for a completed investigation", () => {
    const plan: AgentPlanStep[] = [{ step_id: "step_01", tool_id: "analyze_prompt", status: "succeeded", requires_authorization: true, summary: "运行 Prompt 风险检测", depends_on: [], attempt: 1 }];
    const evidence: AgentEvidence[] = [{ evidence_id: "ev_01", authenticity: "real", source_type: "prompt_detector", source_ref: "task_01", tool_id: "analyze_prompt", summary: "相邻指令改变了系统规则", observed_at: messages[1].created_at, uncertainty: "不能单独证明攻击成功。", metadata: { position: "字符 0-14", confidence: 0.86 } }];

    render(<AgentConversation messages={[{ ...messages[1], kind: "result" }]} plan={plan} evidence={evidence} finalStatus="risk_found" limitations={["需要结合业务上下文复核。"]} />);

    expect(screen.getByRole("heading", { name: "结论" })).toBeVisible();
    expect(screen.getByRole("heading", { name: "可审计执行链" })).toBeVisible();
    expect(screen.getByRole("heading", { name: "证据详情" })).toBeVisible();
    expect(screen.getByRole("heading", { name: "限制说明" })).toBeVisible();
    expect(screen.getByText("ev_01")).toBeVisible();
    expect(screen.getByText("字符 0-14")).toBeVisible();
  });

  it("renders structured agent findings as readable headings and evidence tables", () => {
    render(<AgentConversation messages={[{ ...messages[1], content: "**检测结论：高风险**\n\n| 证据 | 位置 |\n| --- | --- |\n| 提示词注入 | 字符 0-12 |" }]} />);

    expect(screen.getByRole("heading", { name: "检测结论：高风险" })).toBeVisible();
    expect(screen.getByRole("table")).toBeVisible();
    expect(screen.getByRole("columnheader", { name: "证据" })).toBeVisible();
    expect(screen.getByRole("cell", { name: "提示词注入" })).toBeVisible();
  });
});
