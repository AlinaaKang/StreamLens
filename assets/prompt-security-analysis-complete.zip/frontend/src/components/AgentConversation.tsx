import { Bot, CircleAlert, UserRound } from "lucide-react";
import type { ReactNode } from "react";

import type { AgentEvidence, AgentMessage, AgentNextAction, AgentPlanStep, AgentSuggestedQuestion } from "../agent/types";
import { formatAgentMessageTime } from "../agent/messageTime";
import { AgentNextSteps } from "./AgentNextSteps";
import { AgentPlan } from "./AgentPlan";

function renderInline(text: string, keyPrefix: string) {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).filter(Boolean);
  return parts.map((part, index) => {
    const key = `${keyPrefix}-${index}`;
    if (part.startsWith("**") && part.endsWith("**")) return <strong key={key}>{part.slice(2, -2)}</strong>;
    if (part.startsWith("`") && part.endsWith("`")) return <code key={key}>{part.slice(1, -1)}</code>;
    return part;
  });
}

function MessageContent({ content }: { content: string }) {
  if (!/[|*_`#\n]/.test(content)) return <div className="agent-message-content"><p>{content}</p></div>;
  const lines = content.split(/\r?\n/);
  const blocks: ReactNode[] = [];
  let index = 0;
  while (index < lines.length) {
    const line = lines[index];
    if (!line.trim()) { index += 1; continue; }
    if (line.trim().startsWith("|") && index + 1 < lines.length && /^\s*\|?\s*:?-{3,}/.test(lines[index + 1])) {
      const rows: string[][] = [];
      while (index < lines.length && lines[index].trim().startsWith("|")) {
        if (!/^\s*\|?\s*:?-{3,}/.test(lines[index])) rows.push(lines[index].split("|").slice(1, -1).map((cell) => cell.trim()));
        index += 1;
      }
      blocks.push(<div className="agent-message-table" key={`table-${index}`} role="table"><div className="agent-message-table-row is-header" role="row">{rows[0]?.map((cell, cellIndex) => <span role="columnheader" key={cellIndex}>{renderInline(cell, `th-${index}-${cellIndex}`)}</span>)}</div>{rows.slice(1).map((row, rowIndex) => <div className="agent-message-table-row" role="row" key={rowIndex}>{row.map((cell, cellIndex) => <span role="cell" key={cellIndex}>{renderInline(cell, `td-${index}-${rowIndex}-${cellIndex}`)}</span>)}</div>)}</div>);
      continue;
    }
    if (/^\s*[-*]\s+/.test(line)) {
      const items: string[] = [];
      while (index < lines.length && /^\s*[-*]\s+/.test(lines[index])) { items.push(lines[index].replace(/^\s*[-*]\s+/, "")); index += 1; }
      blocks.push(<ul key={`list-${index}`}>{items.map((item, itemIndex) => <li key={itemIndex}>{renderInline(item, `li-${index}-${itemIndex}`)}</li>)}</ul>);
      continue;
    }
    const isHeading = /^#{1,3}\s+/.test(line) || /^\*\*[^*]+\*\*$/.test(line.trim());
    blocks.push(isHeading ? <h3 key={`heading-${index}`}>{renderInline(line.replace(/^#{1,3}\s+/, ""), `heading-${index}`)}</h3> : <p key={`paragraph-${index}`}>{renderInline(line, `line-${index}`)}</p>);
    index += 1;
  }
  return <div className="agent-message-content">{blocks}</div>;
}

const finalStatusLabels: Record<NonNullable<AgentConversationProps["finalStatus"]>, string> = {
  safe: "当前检测范围内未发现异常候选",
  risk_found: "发现异常候选，需要结合证据复核",
  contained: "风险已发现，授权处置已完成验证",
  inconclusive: "证据不足，当前结论不确定",
};

function AgentResultBreakdown({ plan = [], evidence = [], limitations = [], finalStatus }: Pick<AgentConversationProps, "plan" | "evidence" | "limitations" | "finalStatus">) {
  if (!finalStatus) return null;
  const statusText = finalStatusLabels[finalStatus];
  const statusLabel = { safe: "安全", risk_found: "需复核", contained: "已处置", inconclusive: "不确定" }[finalStatus];
  const stepStatus = { waiting: "等待", running: "执行中", succeeded: "完成", failed: "失败", skipped: "跳过" };
  const metadataText = (item: AgentEvidence, key: string, fallback: string) => {
    const value = item.metadata[key];
    return typeof value === "string" || typeof value === "number" ? String(value) : fallback;
  };
  return <section className="agent-result-breakdown" aria-label="调查结果详情">
    <div className="agent-result-conclusion"><h3>结论</h3><p><strong>{statusLabel}</strong>：{statusText}。</p></div>
    <div className="agent-result-section"><h3>可审计执行链</h3><div className="agent-result-table" role="table"><div className="agent-result-row is-header" role="row"><span role="columnheader">阶段</span><span role="columnheader">状态</span><span role="columnheader">内容</span></div>{plan.map((step, index) => <div className="agent-result-row" role="row" key={step.step_id}><span role="cell">{index + 1}</span><span role="cell">{stepStatus[step.status]}</span><span role="cell">{step.summary}</span></div>)}</div></div>
    <div className="agent-result-section"><h3>证据详情</h3>{evidence.length ? <div className="agent-result-table" role="table"><div className="agent-result-row is-header" role="row"><span role="columnheader">证据 ID</span><span role="columnheader">位置</span><span role="columnheader">置信度</span><span role="columnheader">内容说明</span></div>{evidence.slice(0, 20).map((item) => <div className="agent-result-row" role="row" key={item.evidence_id}><span role="cell"><code>{item.evidence_id}</code></span><span role="cell">{metadataText(item, "position", metadataText(item, "packet_range", "公开范围未提供"))}</span><span role="cell">{typeof item.metadata.confidence === "number" ? `${Math.round(item.metadata.confidence * 100)}%` : "未提供"}</span><span role="cell">{item.summary}</span></div>)}</div> : <p className="agent-result-empty">当前没有可定位的公开证据。</p>}</div>
    {limitations.length ? <div className="agent-result-section"><h3>限制说明</h3><ul>{limitations.slice(0, 8).map((item) => <li key={item}>{item}</li>)}</ul></div> : null}
  </section>;
}

type AgentConversationProps = {
  messages: AgentMessage[];
  localContentAvailable?: boolean;
  onClearLocalConversation?: () => void;
  suggestedQuestions?: AgentSuggestedQuestion[];
  nextActions?: AgentNextAction[];
  plan?: AgentPlanStep[];
  planRevision?: number;
  progress?: { finished: number; total: number } | null;
  evidence?: AgentEvidence[];
  limitations?: string[];
  finalStatus?: "safe" | "risk_found" | "contained" | "inconclusive" | null;
  streamingMessageId?: string | null;
  busy?: boolean;
  onQuestion?: (message: string) => void;
  onAction?: (actionId: AgentNextAction["action_id"]) => void;
  now?: Date;
  streamingContent?: string;
};

export function AgentConversation({ messages, localContentAvailable = false, onClearLocalConversation, suggestedQuestions = [], nextActions = [], plan = [], planRevision = 0, progress = null, evidence = [], limitations = [], finalStatus = null, streamingMessageId = null, busy = false, onQuestion = () => undefined, onAction = () => undefined, now, streamingContent = "" }: AgentConversationProps) {
  let planInserted = false;
  const streamingMessageIndex = streamingContent && streamingMessageId
    ? messages.findIndex((message) => message.message_id === streamingMessageId)
    : -1;
  const timeline: ReactNode[] = [];
  messages.forEach((message, index) => {
    const time = formatAgentMessageTime(message.created_at, now);
    const isStreamingMessage = index === streamingMessageIndex;
    const avatar = <span className="agent-message-avatar" aria-hidden="true">{message.role === "user" ? <UserRound size={17} /> : message.kind === "warning" ? <CircleAlert size={17} /> : <Bot size={17} />}</span>;
    const isFinalResult = message.role === "agent" && message.kind === "result" && index === messages.length - 1 && !isStreamingMessage;
    const body = <div className="agent-message-body"><div className="agent-message-heading"><strong>{message.role === "user" ? "你" : "Token Security"}</strong>{isStreamingMessage ? <span className="agent-streaming-indicator">正在生成</span> : <time dateTime={time.dateTime} title={time.full}>{time.short}</time>}</div><MessageContent content={isStreamingMessage ? streamingContent : message.content} />{!isStreamingMessage && message.evidence_scope !== "none" ? <small>{message.evidence_scope === "current_case" ? "基于当前案件证据" : "通用安全知识"}</small> : null}{isFinalResult ? <AgentResultBreakdown plan={plan} evidence={evidence} limitations={limitations} finalStatus={finalStatus} /> : null}</div>;
    timeline.push(<article key={message.message_id} className={`agent-message is-${message.role} is-${message.kind}`}>
      {message.role === "user" ? <>{body}{avatar}</> : <>{avatar}{body}</>}
    </article>);
    if (!planInserted && plan.length && message.role === "user") {
      timeline.push(<AgentPlan key="conversation-plan" steps={plan} revision={planRevision} />);
      if (progress && progress.total > 0) {
        timeline.push(<section className="agent-progress" aria-label="计划进度" key="conversation-progress"><div><span>计划进度</span><strong>{progress.finished} / {progress.total}</strong></div><progress max={progress.total} value={progress.finished} /></section>);
      }
      planInserted = true;
    }
  });
  if (!planInserted && plan.length) {
    const planBlock: ReactNode[] = [<AgentPlan key="conversation-plan" steps={plan} revision={planRevision} />];
    if (progress && progress.total > 0) {
      planBlock.push(<section className="agent-progress" aria-label="计划进度" key="conversation-progress"><div><span>计划进度</span><strong>{progress.finished} / {progress.total}</strong></div><progress max={progress.total} value={progress.finished} /></section>);
    }
    timeline.unshift(...planBlock);
  }
  return (
    <section className="agent-conversation" aria-label="任务对话">
      {localContentAvailable ? <div className="agent-local-conversation-note"><span>原文已保存到当前案件，审计记录仍保持脱敏</span><button type="button" onClick={onClearLocalConversation}>清除浏览器副本</button></div> : null}
      {timeline}
      {streamingContent && streamingMessageIndex < 0 ? <article className="agent-message is-agent is-message"><span className="agent-message-avatar" aria-hidden="true"><Bot size={17} /></span><div className="agent-message-body"><div className="agent-message-heading"><strong>Token Security</strong><span className="agent-streaming-indicator">正在生成</span></div><MessageContent content={streamingContent} /></div></article> : null}
      <AgentNextSteps questions={suggestedQuestions} actions={nextActions} busy={busy} onQuestion={onQuestion} onAction={onAction} />
    </section>
  );
}
