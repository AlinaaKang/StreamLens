import "@testing-library/jest-dom/vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

import { LabPcapWorkspace } from "./LabPcapWorkspace";

afterEach(cleanup);

describe("LabPcapWorkspace", () => {
  it("starts with one fixed attack-method scenario", () => {
    render(<LabPcapWorkspace />);
    expect(screen.getByRole("region", { name: "PCAP 攻防实验场景" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "实验场：攻击手法拆解与规则对抗" })).toBeVisible();
    expect(screen.getByRole("button", { name: "扫描手法拆解" })).toBeVisible();
    expect(screen.queryByLabelText("选择 PCAP 文件")).not.toBeInTheDocument();
  });

  it("starts the preset learning flow without file upload", async () => {
    render(<LabPcapWorkspace />);
    expect(screen.getByText("扫描手法拆解")).toBeVisible();
    fireEvent.click(screen.getByRole("button", { name: "扫描手法拆解" }));
    expect(screen.getByText("正在拆解固定攻击流量")).toBeVisible();
    await waitFor(() => expect(screen.getByText("预置证据分析完成")).toBeVisible());
    expect(screen.getByText(/已定位扫描特征/)).toBeVisible();
  });
});
