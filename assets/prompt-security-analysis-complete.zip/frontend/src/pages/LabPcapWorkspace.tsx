import { FileSearch, ScanSearch, Shield } from "lucide-react";
import { useEffect, useState } from "react";

export function LabPcapWorkspace() {
  const [started, setStarted] = useState(false);
  const [finished, setFinished] = useState(false);
  useEffect(() => { if (!started) return; const timer = window.setTimeout(() => setFinished(true), 700); return () => window.clearTimeout(timer); }, [started]);
  return <section className="lab-pcap-scenario" aria-label="PCAP 攻防实验场景">
    <span className="lab-pcap-hero-icon"><Shield size={30} /></span>
    <h2>实验场：攻击手法拆解与规则对抗</h2>
    <p>专业学习区：通过动手实验理解攻击原理、检测方法与防御手段，所有结论都来自真实检测引擎，不是演示脚本。</p>
    <div className="lab-pcap-choice-label"><span />可以这样开始<span /></div>
    <button type="button" className="lab-pcap-start lab-pcap-single-start" onClick={() => { setStarted(true); setFinished(false); }} disabled={started && !finished}><ScanSearch size={18} />{!started ? "扫描手法拆解" : finished ? "重新运行拆解" : "正在自动分析"}</button>
    {started ? <div className="lab-pcap-learning-note"><FileSearch size={16} /><div><strong>{finished ? "预置证据分析完成" : "正在拆解固定攻击流量"}</strong><span>{finished ? "已定位扫描特征、异常位置，并关联到对应防守规则。" : "系统正在按 Packet 顺序建立基线、定位异常并匹配规则。"}</span></div></div> : null}
  </section>;
}
