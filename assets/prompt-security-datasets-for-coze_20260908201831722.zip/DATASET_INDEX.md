# Prompt 安全分析数据清单

## 可直接上传 Coze

- `data/demo/security-agent-cases.json`：脱敏安全案件证据示例。
- `data/demo/security-agent-playbooks.json`：安全分析和处置剧本。
- `knowledge/snapshots/official-v2/cards.json`：当前版本安全知识卡片。
- `knowledge/snapshots/official-v2/manifest.json`：快照版本和哈希信息。
- `knowledge/sources/official-v2.cards.json`：知识源卡片副本。
- `configs/datasets.yaml`：数据源、许可证、路径和拆分规则。
- `data/README.md`：数据目录、冻结评测和隐私边界。
- `docs/analyze-decision-trace.md`：分析结果轨迹字段和展示边界。

## 评测和报告附件

- `data/agent-ablation-v1-manifest.json`
- `data/agent-ablation-v1-report.json`
- `data/knowledge-evaluation-*.json`
- `data/report-generation-*.json`
- `data/pcap-detection-regression-v1.json`

这些文件用于复现实验配置、聚合指标、哈希和报告校验，不包含逐条原始攻击 Prompt。

## Prompt 分析中实际使用的模型和规则

- 语义模型：配置中的 Semantic Guard（设计文档记录了 Qwen3Guard-Gen-0.6B 接口）。
- 主模型：配置中的 Token/Entropy-CPD 模型。
- Token 信号：Entropy、NLL、CPD 分数、候选告警和异常起点。
- 融合：`backend/app/agent/fusion.py` 中的固定决策表。
- 知识：`knowledge/snapshots/official-v2/` 的官方来源卡片。

## 当前仓库不包含的原始数据

`data/raw/` 没有提交 CPDonline 原始 Prompt、GCG/AutoDAN/AdvPrompter suffix、Token 载荷或模型原始输出。`configs/datasets.yaml` 只记录外部数据源和许可证；拥有合法副本时应在受保护环境中挂载，不要把攻击原文直接上传到公开 Coze 知识库。
