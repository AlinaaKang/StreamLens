Token 侦探挑战相关代码。入口 frontend/src/pages/ChallengePage.tsx；不含密钥、node_modules、原始攻击数据、Token 文本、PCAP 载荷或数据库。
