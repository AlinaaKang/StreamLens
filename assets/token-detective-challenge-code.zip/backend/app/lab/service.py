from __future__ import annotations

import hashlib
import logging
import uuid
from datetime import UTC, datetime
from threading import Lock
from typing import Any

from app.demo.service import DemoSampleNotFound
from app.lab.counterfactual import CounterfactualRunner
from app.lab.execution_models import (
    LabArtifact,
    LabExecuteRequest,
    LabToolExecution,
)
from app.lab.execution_store import SQLiteLabExecutionStore
from app.lab.executors import LabToolExecutor
from app.lab.models import (
    LabDetectionSnapshot,
    LabLatencySummary,
    LabMetrics,
    LabPublicInput,
    LabRunRequest,
    LabRunResult,
    LabScenario,
    LabStage,
    LabToolId,
    REDACTED_INPUT_NOTICE,
    assert_public_payload,
    safer_action,
)
from app.lab.reporting import build_case_report
from app.lab.store import LabRunStore
from app.lab.tools import build_response_plan, execute_dry_run
from app.schemas import AnalysisRequest, AnalysisResult


logger = logging.getLogger(__name__)


_SYNTHETIC_SCENARIOS = {
    "synthetic_safe": (
        "普通无害",
        "Explain why input validation is useful in a web application.",
        "解释 Web 应用输入校验的价值",
    ),
    "synthetic_shift": (
        "无害格式突变",
        "Summarize input validation:\n\n### CHECKLIST ###\n1. Types\n2. Lengths\n3. Encoding",
        "总结输入校验并处理明显格式变化",
    ),
}

_PROTECTED_FAMILY_ORDER = (
    ("direct_unsafe", "直接危险"),
    ("gcg", "GCG 优化攻击"),
    ("autodan", "AutoDAN 优化攻击"),
    ("advprompter", "AdvPrompter 优化攻击"),
)

_PROTECTED_PUBLIC_CONTENT = {
    "direct_unsafe": "直接请求危险或违规内容，具体目标已隐藏。",
    "gcg": "正常请求结构后附加了优化生成的对抗字符串。",
    "autodan": "自然语言角色与指令包装试图改变模型安全边界。",
    "advprompter": "自动化提示生成器构造了对抗性请求。",
}

_PROTECTED_PUBLIC_INTENT_SUMMARIES = {
    "direct_unsafe": "直接危险或违规请求识别",
    "gcg": "优化生成的对抗后缀识别",
    "autodan": "自然语言包装的越狱指令识别",
    "advprompter": "自动生成的对抗提示识别",
}


class LabRunCreationFailed(RuntimeError):
    pass


class LabToolStorageUnavailable(RuntimeError):
    pass


class LabExecutionInvariantViolation(ValueError):
    pass


class LabService:
    def __init__(
        self,
        *,
        workflow: Any,
        demo_service: Any | None = None,
        run_store: LabRunStore[LabRunResult] | None = None,
        execution_store: SQLiteLabExecutionStore | None = None,
    ) -> None:
        self.workflow = workflow
        self.demo_service = demo_service
        self.run_store = run_store or LabRunStore()
        self._execution_store = execution_store
        self._tool_executor = (
            LabToolExecutor(execution_store)
            if execution_store is not None
            else None
        )
        self.counterfactual_runner = CounterfactualRunner(workflow)
        self._privacy_lock = Lock()
        self._privacy_violation_count = 0

    def list_scenarios(self) -> tuple[LabScenario, ...]:
        scenarios = [
            LabScenario(
                scenario_id=scenario_id,
                label=label,
                scenario_kind="synthetic",
                public_input=LabPublicInput(
                    disclosure="full",
                    content=source,
                    intent_summary=intent_summary,
                ),
            )
            for scenario_id, (
                label,
                source,
                intent_summary,
            ) in _SYNTHETIC_SCENARIOS.items()
        ]
        if self.demo_service is not None:
            for family, label in _PROTECTED_FAMILY_ORDER:
                family_samples = self.demo_service.list_samples(
                    family=family, limit=1
                )
                selected = family_samples[0] if family_samples else None
                if selected is not None:
                    scenarios.append(
                        LabScenario(
                            scenario_id=selected.sample_id,
                            label=label,
                            scenario_kind="protected",
                            attack_family=selected.family,
                            public_input=_protected_public_input(selected.family),
                        )
                    )
        catalog = tuple(scenarios)
        self._validate_public(catalog)
        return catalog

    def create_run(self, request: LabRunRequest) -> LabRunResult:
        run_id = f"lab_{uuid.uuid4().hex}"
        input_length = 0
        input_hash = "unavailable"
        try:
            if request.scenario_kind == "custom":
                source = request.custom_input or ""
                input_length = len(source)
                input_hash = _sha256_text(source)
                analysis = self.workflow.analyze(
                    AnalysisRequest(
                        prompt=source,
                        model_id=self.workflow.calibration.model_id,
                        mode=request.mode,
                        knowledge_mode="report",
                    ),
                    request_id=f"lab_base_{uuid.uuid4().hex}",
                )
                counterfactual = self.counterfactual_runner.run(
                    prompt=source,
                    original=analysis,
                    mode=request.mode,
                )
                scenario_id = "custom"
                scenario_kind = "custom"
                scenario_label = "自定义输入"
                attack_family = None
            elif request.sample_id in _SYNTHETIC_SCENARIOS:
                scenario_id = request.sample_id
                scenario_label, source, _intent_summary = _SYNTHETIC_SCENARIOS[
                    scenario_id
                ]
                input_length = len(source)
                input_hash = _sha256_text(source)
                analysis = self.workflow.analyze(
                    AnalysisRequest(
                        prompt=source,
                        model_id=self.workflow.calibration.model_id,
                        mode=request.mode,
                        knowledge_mode="report",
                    ),
                    request_id=f"lab_base_{uuid.uuid4().hex}",
                )
                counterfactual = self.counterfactual_runner.run(
                    prompt=source,
                    original=analysis,
                    mode=request.mode,
                )
                scenario_kind = "synthetic"
                attack_family = None
            else:
                if self.demo_service is None or request.sample_id is None:
                    raise DemoSampleNotFound(request.sample_id or "missing")
                scenario_id = request.sample_id
                attack_family, analysis, counterfactual = (
                    self.demo_service.analyze_for_lab(
                        scenario_id,
                        self.workflow,
                        mode=request.mode,
                        counterfactual_runner=self.counterfactual_runner,
                    )
                )
                scenario_kind = "protected"
                scenario_label = _protected_label(attack_family)

            run = self._assemble_run(
                run_id=run_id,
                scenario_id=scenario_id,
                scenario_kind=scenario_kind,
                scenario_label=scenario_label,
                attack_family=attack_family,
                mode=request.mode,
                analysis=analysis,
                counterfactual=counterfactual,
            )
            self.run_store.put(run)
            logger.info(
                "lab run completed run_id=%s input_sha256=%s input_chars=%d status=completed",
                run_id,
                input_hash,
                input_length,
            )
            return run
        except Exception as exc:
            logger.error(
                "lab run failed run_id=%s input_sha256=%s input_chars=%d error_type=%s",
                run_id,
                input_hash,
                input_length,
                type(exc).__name__,
            )
            raise LabRunCreationFailed("lab_run_failed") from None

    def get_run(self, run_id: str) -> LabRunResult:
        return self.run_store.get(run_id)

    def run_tool(
        self,
        run_id: str,
        tool_id: LabToolId | str,
        *,
        inject_failure: bool,
    ) -> LabRunResult:
        selected_tool = LabToolId(tool_id)
        run = self.run_store.get(run_id)
        plan = next(
            item for item in run.tool_plans if item.tool_id is selected_tool
        )
        result = execute_dry_run(plan, inject_failure=inject_failure)
        tool_results = tuple(
            item for item in run.tool_results if item.tool_id is not selected_tool
        ) + (result,)
        report = build_case_report(
            decision=run.detection.decision,
            evidence=run.detection.knowledge_evidence,
            counterfactual=run.counterfactual,
            tool_results=tool_results,
            requested_evidence_ids=tuple(
                item.knowledge_id for item in run.detection.knowledge_evidence
            ),
        )
        updated = run.model_copy(
            update={"tool_results": tool_results, "case_report": report}
        )
        self._validate_public(updated)
        self.run_store.put(updated)
        return updated

    def execute_tool(
        self,
        run_id: str,
        tool_id: LabToolId,
        request: LabExecuteRequest,
    ) -> tuple[LabToolExecution, bool]:
        run = self.run_store.get(run_id)
        executor = self._tool_executor
        if executor is None:
            raise LabToolStorageUnavailable("lab_tool_storage_unavailable")
        bundle = executor.execute(run, tool_id, request.idempotency_key)
        execution = bundle.execution
        if (
            execution.run_id != run.run_id
            or execution.tool_id is not tool_id
            or execution.idempotency_key != request.idempotency_key
            or execution.source_action != run.detection.decision
            or execution.effective_action
            != safer_action(run.detection.decision, execution.effective_action)
        ):
            raise LabExecutionInvariantViolation(
                "execution must preserve the stored run decision"
            )
        self._validate_public(execution)
        return execution, bundle.newly_created

    def list_executions(self, run_id: str) -> tuple[LabToolExecution, ...]:
        store = self._require_execution_store()
        try:
            executions = store.list_executions(run_id)
        except Exception:
            raise LabToolStorageUnavailable(
                "lab_tool_storage_unavailable"
            ) from None
        self._validate_public(executions)
        return executions

    def get_artifact(self, artifact_id: str) -> LabArtifact:
        store = self._require_execution_store()
        try:
            return store.get_artifact(artifact_id)
        except LookupError:
            raise
        except Exception:
            raise LabToolStorageUnavailable(
                "lab_tool_storage_unavailable"
            ) from None

    def metrics(self) -> LabMetrics:
        runs = self.run_store.snapshot()
        run_count = len(runs)
        eligible = sum(run.counterfactual.char_start is not None for run in runs)
        executed = sum(run.counterfactual.rechecked is not None for run in runs)
        agreement = sum(_evidence_relation(run) == "agreement" for run in runs)
        conflict = sum(_evidence_relation(run) == "conflict" for run in runs)
        tool_results = [result for run in runs for result in run.tool_results]
        tool_success = sum(result.status == "succeeded" for result in tool_results)
        tool_failure = sum(result.status == "failed" for result in tool_results)
        generated = sum(run.case_report.report_status == "deterministic" for run in runs)
        fallback = sum(run.case_report.report_status == "fallback" for run in runs)
        executions = tuple(
            (run, execution)
            for run in runs
            for execution in (
                self._execution_store.list_executions(run.run_id)
                if self._execution_store is not None
                else ()
            )
        )
        preserved_actions = sum(
            execution.effective_action == run.detection.decision
            for run, execution in executions
        )
        latencies = [run.detection.latency_ms for run in runs]
        metrics = LabMetrics(
            run_count=run_count,
            counterfactual_eligible_count=eligible,
            counterfactual_executed_count=executed,
            counterfactual_execution_rate=_rate(executed, eligible),
            evidence_agreement_count=agreement,
            evidence_conflict_count=conflict,
            evidence_conflict_rate=_rate(conflict, agreement + conflict),
            tool_success_count=tool_success,
            tool_failure_count=tool_failure,
            tool_success_rate=_rate(tool_success, tool_success + tool_failure),
            report_generated_count=generated,
            report_fallback_count=fallback,
            confirmed_execution_count=len(executions),
            preserved_action_execution_count=preserved_actions,
            action_preservation_rate=(
                _rate(preserved_actions, len(executions)) if executions else None
            ),
            latency_ms=LabLatencySummary(
                p50=_percentile(latencies, 0.5),
                p95=_percentile(latencies, 0.95),
            ),
            privacy_violation_count=self._privacy_violations(),
        )
        self._validate_public(metrics)
        return metrics

    def _validate_public(self, payload: Any) -> None:
        try:
            assert_public_payload(payload)
        except ValueError:
            with self._privacy_lock:
                self._privacy_violation_count += 1
            raise

    def _privacy_violations(self) -> int:
        with self._privacy_lock:
            return self._privacy_violation_count

    def _require_execution_store(self) -> SQLiteLabExecutionStore:
        if self._execution_store is None:
            raise LabToolStorageUnavailable("lab_tool_storage_unavailable")
        return self._execution_store

    def _assemble_run(
        self,
        *,
        run_id: str,
        scenario_id: str,
        scenario_kind: str,
        scenario_label: str,
        attack_family: str | None,
        mode: str,
        analysis: AnalysisResult,
        counterfactual: Any,
    ) -> LabRunResult:
        detection = LabDetectionSnapshot.from_analysis(analysis)
        plans = build_response_plan(
            decision=analysis.decision,
            fusion_reason=analysis.fusion_reason,
            mode=mode,
            evidence=analysis.knowledge_evidence,
        )
        evidence_ids = tuple(
            item.knowledge_id for item in analysis.knowledge_evidence
        )
        report = build_case_report(
            decision=analysis.decision,
            evidence=analysis.knowledge_evidence,
            counterfactual=counterfactual,
            tool_results=(),
            requested_evidence_ids=evidence_ids,
        )
        run = LabRunResult(
            run_id=run_id,
            scenario_id=scenario_id,
            scenario_kind=scenario_kind,
            scenario_label=scenario_label,
            attack_family=attack_family,
            mode=mode,
            created_at=datetime.now(UTC).isoformat(),
            stages=_stages(analysis),
            detection=detection,
            counterfactual=counterfactual,
            tool_plans=plans,
            case_report=report,
        )
        self._validate_public(run)
        return run


def _stages(result: AnalysisResult) -> tuple[LabStage, ...]:
    combined_detection = max(
        result.latency_ms - result.semantic_latency_ms - result.knowledge_latency_ms,
        0.0,
    )
    knowledge_ready = result.knowledge_status.value in {"ready", "degraded"}
    return (
        LabStage(
            stage_id="semantic_guard",
            status=(
                "unavailable"
                if result.semantic_severity.value == "unavailable"
                else "succeeded"
            ),
            latency_ms=result.semantic_latency_ms,
            timing_basis="measured",
            summary="语义安全等级与类别已归一化。",
        ),
        LabStage(
            stage_id="token_observation",
            status="succeeded",
            latency_ms=combined_detection,
            timing_basis="combined",
            summary="Token 观测与 CPD 使用组合耗时。",
        ),
        LabStage(
            stage_id="entropy_cpd",
            status="succeeded",
            timing_basis="unavailable",
            summary="Entropy-CPD 产生异常候选和预测起点。",
        ),
        LabStage(
            stage_id="fixed_fusion",
            status="succeeded",
            timing_basis="unavailable",
            summary="固定融合表生成基础动作。",
        ),
        LabStage(
            stage_id="knowledge_retrieval",
            status="succeeded" if knowledge_ready else "unavailable",
            latency_ms=(result.knowledge_latency_ms if knowledge_ready else None),
            timing_basis="measured" if knowledge_ready else "unavailable",
            summary=(
                "本地知识证据已附加，且不改变基础动作。"
                if knowledge_ready
                else "知识层不可用，保留基础检测结果。"
            ),
        ),
    )


def _sha256_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()


def _protected_label(family: str) -> str:
    normalized = family.casefold()
    for expected, label in _PROTECTED_FAMILY_ORDER:
        if normalized == expected:
            return label
    return f"{family} 冻结样本"


def _protected_public_input(family: str) -> LabPublicInput:
    normalized_family = family.strip().casefold()
    return LabPublicInput(
        disclosure="redacted",
        content=_PROTECTED_PUBLIC_CONTENT.get(
            normalized_family, "受保护对抗样本，具体内容已隐藏。"
        ),
        intent_summary=_PROTECTED_PUBLIC_INTENT_SUMMARIES.get(
            normalized_family, "识别受保护的对抗请求"
        ),
        redaction_notice=REDACTED_INPUT_NOTICE,
    )


def _rate(numerator: int, denominator: int) -> float:
    return numerator / denominator if denominator else 0.0


def _percentile(values: list[float], quantile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    position = (len(ordered) - 1) * quantile
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = position - lower
    return ordered[lower] + fraction * (ordered[upper] - ordered[lower])


def _evidence_relation(run: LabRunResult) -> str:
    semantic_severity = run.detection.semantic_severity.value
    if semantic_severity not in {"safe", "unsafe"}:
        return "unavailable"
    semantic_alert = semantic_severity == "unsafe"
    cpd_alert = run.detection.detector_status == "token_anomaly_candidate"
    return "agreement" if semantic_alert == cpd_alert else "conflict"
