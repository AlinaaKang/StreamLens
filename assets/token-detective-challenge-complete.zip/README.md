# Token 侦探挑战：完整源码包

这是当前 Token Security Agent 项目中 Token 侦探挑战的自包含导出包。它保留了从页面入口到后端 Lab 场景、检测结果、角色调查、评分和测试的完整源码结构，便于本地运行、交给开发者复刻，或作为 Coze 工具/知识库的实现参考。

## 包含内容

- `frontend/`：完整 React + Vite 前端源码、路由、挑战页面、角色公仔、轨迹回放、调查状态机、题目和评分逻辑。
- `backend/app/`：完整 FastAPI 应用源码；其中 `app/lab/` 是挑战使用的固定场景、运行记录、工具回执、反事实检查和报告实现。
- `tests/`：前后端相关测试及隐私边界测试。
- `data/`、`knowledge/`、`configs/`：脱敏演示数据、知识快照、评测清单和数据来源配置。
- `docs/`：挑战玩法、评分、数据边界和实现说明。
- `frontend/public/mascots/`：三名侦探公仔素材（WebP）。
- `EXPORT-MANIFEST.txt`：本包实际文件清单。

## Token 侦探挑战入口

前端入口：`frontend/src/pages/ChallengePage.tsx`

核心模块：

- `frontend/src/challenge/definitions.ts`：三关速战、五关完整挑战的关卡定义。
- `frontend/src/challenge/session.ts`：设置、调查、作答、揭晓、重试、退出状态机。
- `frontend/src/challenge/investigation.ts`：Guard、CPD、Agent 三角色的解锁顺序与回看状态。
- `frontend/src/challenge/roleAuditLines.ts`：将结构化检测证据映射为逐行可审计轨迹。
- `frontend/src/challenge/scoring.ts`：动作、证据关系、Token 起点的确定性评分。
- `frontend/src/components/MascotTeam.tsx`：三名公仔的站位、状态和动画。
- `frontend/src/components/InvestigationDesk.tsx`、`RoleAuditPlayback.tsx`：证据台与轨迹回放。
- `backend/app/lab/service.py`：固定合成场景、受保护场景目录、检测运行和结果组装。
- `backend/app/api/lab.py`：`/api/v1/lab/scenarios`、`/runs`、工具 dry-run/execute 等接口。

角色轨迹是已返回结构化证据的界面回放，不是隐藏思维链，也不是实时模型推理。浏览器只接收脱敏字段，不保存原始 Prompt、攻击 suffix、Token 文本/ID、模型原始输出或 PCAP 载荷。

## 本地运行

```powershell
cd frontend
npm install
npm run dev -- --host 127.0.0.1 --port 5174
```

后端依赖见根目录 `pyproject.toml`，入口为 `backend/app/main.py`。挑战需要后端 Lab 服务可用；未配置模型或 GPU 时，项目会按文档中的固定降级边界运行。真实检测还需要在受保护环境提供模型和相应数据路径。

## Coze 导入建议

优先将以下内容作为知识库或实现参考上传：

- `data/demo/security-agent-cases.json`
- `data/demo/security-agent-playbooks.json`
- `knowledge/snapshots/official-v2/`
- `configs/datasets.yaml`
- `data/README.md`
- `docs/token-detective-challenge.md`

完整源码用于复刻 UI 和工具编排；Coze 的对话模型可以负责解释和引导，本地检测引擎负责生成结构化证据。评测清单中的样本数量是冻结统计，不等于包内存在同数量的原始 Prompt。

## 未包含内容

- CPDonline、GCG、AutoDAN、AdvPrompter 的完整原始 Prompt 和攻击 suffix。
- 原始 Token 文本/ID、模型原始输出和真实 PCAP 载荷。
- 密钥、`.secrets/`、`node_modules/`、构建产物、临时文件、日志和 Git 元数据。

这些内容要受许可证、隐私和安全边界约束，不能用占位数据伪造。包内的 `configs/datasets.yaml`、`data/README.md` 和 `THIRD_PARTY_NOTICES.md` 记录了来源与导入规则。
