# Token 侦探挑战完整导出包

这个目录是 Token Security 项目中“Token 侦探挑战”的可移交版本，包含：

- 挑战页面和全部交互代码
- 三名侦探公仔的原始 WebP 素材
- 角色调查状态机、证据逐行回放和自动演示轨迹
- 关卡定义、题目输入、评分和会话状态机
- 后端固定场景目录与 Lab Run 接口实现
- 前端和后端相关测试
- 当前仓库已经存在的安全数据、知识快照、评测清单和报告

## 快速查看

前端源码保留原仓库路径，可直接从 `frontend/` 合并回项目。挑战入口是：

```text
http://127.0.0.1:5174/challenge
```

启动前端：

```powershell
cd frontend
npm install
npm run dev -- --host 127.0.0.1 --port 5174
```

挑战页面依赖后端：

```text
GET  /api/v1/lab/scenarios
POST /api/v1/lab/runs
GET  /api/v1/health
```

## Token 侦探挑战的实现边界

1. `frontend/src/pages/ChallengePage.tsx` 是页面编排入口。
2. `frontend/src/components/MascotTeam.tsx` 是三名公仔、站位、状态和动画映射。
3. `frontend/src/components/InvestigationDesk.tsx` 与 `RoleAuditPlayback.tsx` 负责中央证据台和逐行轨迹回放。
4. `frontend/src/challenge/investigation.ts` 是 Guard、CPD、Agent 三角色的解锁顺序和回看状态机。
5. `frontend/src/challenge/definitions.ts` 是三关速战/五关完整挑战的关卡组解析。
6. `frontend/src/challenge/scoring.ts` 是动作 50 分、证据关系 20 分、Token 起点 30 分的确定性评分。
7. `frontend/src/challenge/session.ts` 是开始、调查、作答、揭晓、重试和退出状态机。
8. `backend/app/lab/service.py` 提供固定场景目录和已脱敏的 Lab Run 结果。

角色轨迹不是实时模型思维链。它是对后端已经返回的结构化证据进行可审计的界面回放：

- 互动调查逐行间隔默认 420ms；
- 自动演示阶段间隔默认 700ms；
- 可跳过回放；
- 不展示隐藏思维链、攻击原文或原始模型输出。

## 数据集说明

`data/` 和 `knowledge/` 中的文件是当前仓库实际存在、可复制的安全数据和知识快照。它们包括脱敏演示案例、数据集清单、哈希、评测报告和知识卡片。

仓库没有 `data/raw/` 中的 CPDonline 原始 Prompt、攻击 suffix 或原始 PCAP 载荷；这些数据需要在拥有相应许可证的环境中由外部路径挂载。`configs/datasets.yaml` 和 `data/README.md` 记录了来源、许可证、版本和导入规则。导出包不会伪造或补生成不存在的原始数据。

受保护攻击关卡在浏览器中只展示 GCG、AutoDAN、AdvPrompter 的家族级说明，原始攻击内容保持隐藏。这是项目的隐私和许可证边界，不影响 Coze 使用脱敏案例、知识快照和数据集说明搭建原型。

## Coze 使用建议

优先上传：

- `data/demo/security-agent-cases.json`
- `data/demo/security-agent-playbooks.json`
- `knowledge/snapshots/official-v2/`
- `configs/datasets.yaml`
- `data/README.md`
- `docs/token-detective-challenge.md`

前端和后端代码用于复刻界面与工具编排；Coze 知识库应使用上面的脱敏数据和知识文件，不应把攻击原文、Token 文本、原始模型输出或隐藏推理上传到公开知识库。
