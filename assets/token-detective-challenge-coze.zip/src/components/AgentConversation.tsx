import { Bot, CircleAlert, UserRound } from "lucide-react";
import type { ReactNode } from "react";

import type { AgentMessage, AgentNextAction, AgentPlanStep, AgentSuggestedQuestion } from "../agent/types";
import { formatAgentMessageTime } from "../agent/messageTime";
import { AgentNextSteps } from "./AgentNextSteps";
import { AgentPlan } from "./AgentPlan";

function renderInline(text: string, keyPrefix: string) {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).filter(Boolean);
  return parts.map((part, index) => {
    const key = `${keyPrefix}-${index}`;
    if (part.startsWith("**") && part.endsWith("**")) return <strong key={key}>{part.slice(2, -2)}</strong>;
    if (part.startsWith("`") && part.endsWith("`")) return <code key={key}>{part.slice(1, -1)}</code>;
    return part;
  });
}

function MessageContent({ content }: { content: string }) {
  if (!/[|*_`#\n]/.test(content)) return <div className="agent-message-content"><p>{content}</p></div>;
  const lines = content.split(/\r?\n/);
  const blocks: ReactNode[] = [];
  let index = 0;
  while (index < lines.length) {
    const line = lines[index];
    if (!line.trim()) { index += 1; continue; }
    if (line.trim().startsWith("|") && index + 1 < lines.length && /^\s*\|?\s*:?-{3,}/.test(lines[index + 1])) {
      const rows: string[][] = [];
      while (index < lines.length && lines[index].trim().startsWith("|")) {
        if (!/^\s*\|?\s*:?-{3,}/.test(lines[index])) rows.push(lines[index].split("|").slice(1, -1).map((cell) => cell.trim()));
        index += 1;
      }
      blocks.push(<div className="agent-message-table" key={`table-${index}`} role="table"><div className="agent-message-table-row is-header" role="row">{rows[0]?.map((cell, cellIndex) => <span role="columnheader" key={cellIndex}>{renderInline(cell, `th-${index}-${cellIndex}`)}</span>)}</div>{rows.slice(1).map((row, rowIndex) => <div className="agent-message-table-row" role="row" key={rowIndex}>{row.map((cell, cellIndex) => <span role="cell" key={cellIndex}>{renderInline(cell, `td-${index}-${rowIndex}-${cellIndex}`)}</span>)}</div>)}</div>);
      continue;
    }
    if (/^\s*[-*]\s+/.test(line)) {
      const items: string[] = [];
      while (index < lines.length && /^\s*[-*]\s+/.test(lines[index])) { items.push(lines[index].replace(/^\s*[-*]\s+/, "")); index += 1; }
      blocks.push(<ul key={`list-${index}`}>{items.map((item, itemIndex) => <li key={itemIndex}>{renderInline(item, `li-${index}-${itemIndex}`)}</li>)}</ul>);
      continue;
    }
    const isHeading = /^#{1,3}\s+/.test(line) || /^\*\*[^*]+\*\*$/.test(line.trim());
    blocks.push(isHeading ? <h3 key={`heading-${index}`}>{renderInline(line.replace(/^#{1,3}\s+/, ""), `heading-${index}`)}</h3> : <p key={`paragraph-${index}`}>{renderInline(line, `line-${index}`)}</p>);
    index += 1;
  }
  return <div className="agent-message-content">{blocks}</div>;
}

type AgentConversationProps = {
  messages: AgentMessage[];
  localContentAvailable?: boolean;
  onClearLocalConversation?: () => void;
  suggestedQuestions?: AgentSuggestedQuestion[];
  nextActions?: AgentNextAction[];
  plan?: AgentPlanStep[];
  planRevision?: number;
  busy?: boolean;
  onQuestion?: (message: string) => void;
  onAction?: (actionId: AgentNextAction["action_id"]) => void;
  now?: Date;
  streamingContent?: string;
};

export function AgentConversation({ messages, localContentAvailable = false, onClearLocalConversation, suggestedQuestions = [], nextActions = [], plan = [], planRevision = 0, busy = false, onQuestion = () => undefined, onAction = () => undefined, now, streamingContent = "" }: AgentConversationProps) {
  let planInserted = false;
  const timeline: ReactNode[] = [];
  messages.forEach((message) => {
    const time = formatAgentMessageTime(message.created_at, now);
    const avatar = <span className="agent-message-avatar" aria-hidden="true">{message.role === "user" ? <UserRound size={17} /> : message.kind === "warning" ? <CircleAlert size={17} /> : <Bot size={17} />}</span>;
    const body = <div className="agent-message-body"><div className="agent-message-heading"><strong>{message.role === "user" ? "你" : "Token Security"}</strong><time dateTime={time.dateTime} title={time.full}>{time.short}</time></div><MessageContent content={message.content} />{message.evidence_scope !== "none" ? <small>{message.evidence_scope === "current_case" ? "基于当前案件证据" : "通用安全知识"}</small> : null}</div>;
    timeline.push(<article key={message.message_id} className={`agent-message is-${message.role} is-${message.kind}`}>
      {message.role === "user" ? <>{body}{avatar}</> : <>{avatar}{body}</>}
    </article>);
    if (!planInserted && plan.length && message.role === "user") {
      timeline.push(<AgentPlan key="conversation-plan" steps={plan} revision={planRevision} />);
      planInserted = true;
    }
  });
  if (!planInserted && plan.length) timeline.unshift(<AgentPlan key="conversation-plan" steps={plan} revision={planRevision} />);
  return (
    <section className="agent-conversation" aria-label="任务对话">
      {localContentAvailable ? <div className="agent-local-conversation-note"><span>原文已保存到当前案件，审计记录仍保持脱敏</span><button type="button" onClick={onClearLocalConversation}>清除浏览器副本</button></div> : null}
      {timeline}
      {streamingContent ? <article className="agent-message is-agent is-message"><span className="agent-message-avatar" aria-hidden="true"><Bot size={17} /></span><div className="agent-message-body"><div className="agent-message-heading"><strong>Token Security</strong><span className="agent-streaming-indicator">正在生成</span></div><MessageContent content={streamingContent} /></div></article> : null}
      <AgentNextSteps questions={suggestedQuestions} actions={nextActions} busy={busy} onQuestion={onQuestion} onAction={onAction} />
    </section>
  );
}
