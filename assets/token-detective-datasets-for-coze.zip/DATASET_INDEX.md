# Coze 数据上传清单

## 推荐直接上传

| 文件或目录 | 用途 |
| --- | --- |
| `data/demo/security-agent-cases.json` | 脱敏安全案件和证据示例 |
| `data/demo/security-agent-playbooks.json` | 安全调查/处置剧本 |
| `knowledge/snapshots/official-v2/cards.json` | 当前安全知识卡片 |
| `knowledge/snapshots/official-v2/manifest.json` | 知识快照版本和校验信息 |
| `configs/datasets.yaml` | 数据源、许可证、拆分和冻结规则 |
| `data/README.md` | 数据目录和隐私边界 |
| `docs/token-detective-challenge.md` | Token 侦探挑战玩法、评分和数据边界 |

## 可作为评测附件上传

- `data/agent-ablation-v1-manifest.json`
- `data/agent-ablation-v1-report.json`
- `data/knowledge-evaluation-v1.json`
- `data/knowledge-evaluation-report-v1.json`
- `data/knowledge-evaluation-v2-development.json`
- `data/knowledge-evaluation-v2-development-report.json`
- `data/knowledge-evaluation-v2-test.json`
- `data/knowledge-evaluation-v2-test-report.json`
- `data/report-generation-*.json`
- `data/pcap-detection-regression-v1.json`

这些文件主要是评测配置、聚合指标、报告校验和回归记录，不是逐条攻击 Prompt 数据。

## 挑战实际运行数据来源

Token 侦探挑战调用后端 `GET /api/v1/lab/scenarios`。固定无害场景在 `backend/app/lab/service.py` 的 `_SYNTHETIC_SCENARIOS` 中定义；受保护场景从 Demo 服务选取一个已登记的 sample ID，再返回家族级脱敏说明。浏览器不会接收原始攻击 Prompt、Token 文本或原始模型输出。

## 仓库没有的原始数据

以下目录在当前仓库不存在，因此不能直接打包：

- `data/raw/CPDonline` 原始 Prompt 和攻击 suffix
- 原始 Token 载荷
- 原始 PCAP 载荷

来源和导入命令记录在 `configs/datasets.yaml`、`data/README.md` 以及项目根目录 `THIRD_PARTY_NOTICES.md`。如果你拥有这些数据的合法副本，可以在受保护环境中挂载后再导入 Coze；不要把攻击原文直接放到公开知识库。
